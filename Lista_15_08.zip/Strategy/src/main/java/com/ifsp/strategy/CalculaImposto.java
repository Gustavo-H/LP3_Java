package com.ifsp.strategy;

interface CalculaImposto {

    double calculaSalarioComImposto(Funcionario umFuncionario);
}
