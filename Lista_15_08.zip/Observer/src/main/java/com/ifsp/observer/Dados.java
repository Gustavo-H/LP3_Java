package com.ifsp.observer;

public class Dados {

    int valorA, valorB, valorC;

    public Dados(int a, int b, int c) {
        valorA = a;
        valorB = b;
        valorC = c;
    }
}
